export class CreatePatientDto {
  phoneNumber: string;
  name: string;
}
