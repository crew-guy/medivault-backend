export class CreateDoctorDto {
  qualification: string;
  imgUrl: string;
  experience: string;
}
